<?php
namespace my;

class Test
{
   public function sayHello()
   {
       echo 'hello';
   }
}
