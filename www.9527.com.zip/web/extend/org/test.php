<?php
namespace org;

class Test
{
  public function sayHello()
  {
      echo 'hello';
  }
}
