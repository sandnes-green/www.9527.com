<?php
  namespace app\home\controller;
  use think\Controller;
  class TestMiddle extends Controller{
      public function test($name=''){
        echo "没有重定向";
      }
  }
