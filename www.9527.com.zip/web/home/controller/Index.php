<?php
  namespace app\home\controller;
//  use think\facade\Config;
//  use think\Hook;
//  use think\Behavior;
  use think\Controller;
  use app\common\Demo;
//  use think\View;
  use think\facade\Hook;
  use think\facade\Route;
  class Index extends Controller{
    public function index(){
      return $this->fetch('index');
    }

    public function test($name=''){

      echo "$name";
    }

    public function hello(Demo $demo){
      $demo->setName('ThinkPHP5.1');
      return $demo->getName();
    }

    public function setClass(){
      \think\container::set('temp','\app\common\Demo');

      $tmp = \think\container::get('temp',['name'=>'小可爱']);

      return $tmp->getName();
    }

    public function setClosure(){
      \think\container::set('temp',function($name){
        return '我是一只可爱的:'.$name;
      });
      return \think\container::get('temp',['name'=>'小仓鼠']);
    }

    public function appTest(){
      bind('test','\app\common\Demo');
      $test = app('test');
      return $test->getName();
    }

    public function hookTest(){
      Hook::listen('Test');
    }

  }
