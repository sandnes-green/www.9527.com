<?php
  namespace app\home\behavior;


  class Test
  {
      public function run()
      {
          // 行为逻辑
          echo "钩子测试";
      }
  }
